// dashboard.cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;

int main(){
    cout << "Content-Type: text/html\n\n";
    ifstream in("parking_log.csv");
    cout << "<html><head><meta charset='utf-8'><title>Dashboard</title></head><body style='background:#0d0d0d;color:#eee;font-family:Arial;padding:18px'>";
    cout << "<div style='max-width:1000px;margin:auto;background:#121215;padding:18px;border-radius:10px'>";
    cout << "<h2>Parking Dashboard</h2>";

    if(!in.is_open()){
        cout << "<p style='color:orange'>No records yet. Add entries first.</p>";
        cout << "<p><a href='index.html' style='color:#9adf73'>Home</a></p></div></body></html>";
        return 0;
    }

    string line;
    vector<vector<string>> rows;
    double totalIncome = 0;
    int totalRecords = 0;

    while (getline(in, line)) {
        if (line.empty()) continue;
        vector<string> cols;
        string cell;
        stringstream ss(line);
        while (getline(ss, cell, ',')) cols.push_back(cell);
        // Expecting: owner,vehicle,vehicletype,phone,slot,purpose,entry,exit,hours,amount,notes
        if (cols.size() < 11) continue;
        rows.push_back(cols);
        totalRecords++;
        double amt = 0;
        try { amt = stod(cols[9]); } catch(...) { amt = 0; }
        totalIncome += amt;
    }
    in.close();

    cout << "<p>Total records: <b>" << totalRecords << "</b> &nbsp; Total income: <b>Rs. " << fixed << setprecision(2) << totalIncome << "</b></p>";

    cout << "<table style='width:100%;border-collapse:collapse;font-size:13px;color:#ddd'><thead><tr style='text-align:left'>";
    cout << "<th style='padding:8px;border-bottom:1px solid rgba(255,255,255,0.06)'>Owner</th>";
    cout << "<th>Vehicle</th><th>Type</th><th>Phone</th><th>Slot</th><th>Purpose</th><th>Entry</th><th>Exit</th><th>Hours</th><th>Fee</th><th>Notes</th>";
    cout << "</tr></thead><tbody>";
    for(auto &r: rows){
        cout << "<tr style='border-bottom:1px solid rgba(255,255,255,0.03)'>";
        for(int i=0;i<11;i++){
            cout << "<td style='padding:8px;vertical-align:top'>" << r[i] << "</td>";
        }
        cout << "</tr>";
    }
    cout << "</tbody></table>";
    cout << "<p style='margin-top:12px'><a href='parking_log.csv' download style='color:#9adf73'>Download CSV</a> &nbsp; <a href='index.html' style='color:#9adf73'>Home</a></p>";
    cout << "</div></body></html>";
    return 0;
}

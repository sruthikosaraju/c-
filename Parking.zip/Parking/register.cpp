#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void ensureFile() {
    ofstream f("students.txt", ios::app);
    f.close();
}

bool studentExists(int r) {
    ifstream fin("students.txt");
    int roll;
    string name, status;

    while (fin >> roll >> name >> status) {
        if (roll == r) {
            fin.close();
            return true;
        }
    }
    fin.close();
    return false;
}

void addStudent() {
    ensureFile();

    int roll;
    string name;

    cout << "Enter Roll Number: ";
    cin >> roll;

    if (studentExists(roll)) {
        cout << "Student Already Exists!\n";
        return;
    }

    cout << "Enter Student Name: ";
    cin >> name;

    ofstream fout("students.txt", ios::app);
    fout << roll << " " << name << " Not_Marked\n";
    fout.close();

    cout << "Student Added Successfully!\n";
}

void markAttendance() {
    ensureFile();

    int r, roll;
    string name, status, newStatus;
    bool found = false;

    cout << "Enter Roll Number to Mark Attendance: ";
    cin >> r;

    ifstream fin("students.txt");
    ofstream fout("temp.txt");

    while (fin >> roll >> name >> status) {
        if (roll == r) {
            found = true;
            cout << "Enter Attendance (Present/Absent): ";
            cin >> newStatus;
            fout << roll << " " << name << " " << newStatus << "\n";
        } else {
            fout << roll << " " << name << " " << status << "\n";
        }
    }

    fin.close();
    fout.close();

    remove("students.txt");
    rename("temp.txt", "students.txt");

    if (found)
        cout << "Attendance Updated Successfully!\n";
    else
        cout << "Student Not Found!\n";
}

void searchStudent() {
    ensureFile();

    int r, roll;
    string name, status;
    bool found = false;

    cout << "Enter Roll Number to Search: ";
    cin >> r;

    ifstream fin("students.txt");

    while (fin >> roll >> name >> status) {
        if (roll == r) {
            found = true;
            cout << "\nStudent Details:\n";
            cout << "Roll Number: " << roll << "\n";
            cout << "Name: " << name << "\n";
            cout << "Attendance: " << status << "\n";
            break;
        }
    }

    fin.close();

    if (!found)
        cout << "Student Not Found!\n";
}

void viewAttendance() {
    ensureFile();

    ifstream fin("students.txt");
    int roll;
    string name, status;

    cout << "\n----------- Attendance List -----------\n";

    while (fin >> roll >> name >> status) {
        cout << roll << "  " << name << "  " << status << "\n";
    }

    fin.close();
}

int main() {
    int choice;

    while (true) {
        cout << "\n===== Student Attendance Register =====\n";
        cout << "1. Add Student\n";
        cout << "2. Mark Attendance\n";
        cout << "3. View Attendance\n";
        cout << "4. Search Student\n";
        cout << "5. Exit\n";
        cout << "Enter Your Choice: ";
        cin >> choice;

        switch (choice) {
            case 1: addStudent(); break;
            case 2: markAttendance(); break;
            case 3: viewAttendance(); break;
            case 4: searchStudent(); break;
            case 5: return 0;
            default: cout << "Invalid Choice!\n";
        }
    }
}
// parking.cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <ctime>
#include <vector>
#include <iomanip>
using namespace std;

string urlDecode(const string &src) {
    string ret;
    char ch;
    int i, len = src.length();
    for (i = 0; i < len; i++) {
        if (src[i] == '%') {
            int val;
            sscanf(src.substr(i+1,2).c_str(), "%x", &val);
            ch = static_cast<char>(val);
            ret += ch;
            i += 2;
        } else if (src[i] == '+') {
            ret += ' ';
        } else {
            ret += src[i];
        }
    }
    return ret;
}

string getParam(const string &qs, const string &key) {
    size_t pos = qs.find(key + "=");
    if (pos == string::npos) return "";
    pos += key.length() + 1;
    size_t end = qs.find('&', pos);
    string val = (end == string::npos) ? qs.substr(pos) : qs.substr(pos, end - pos);
    return urlDecode(val);
}

// Convert "YYYY-MM-DDTHH:MM" to time_t
time_t parseDateTime(const string &dt) {
    struct tm t = {};
    if (dt.size() < 16) return 0;
    sscanf(dt.c_str(), "%d-%d-%dT%d:%d", &t.tm_year, &t.tm_mon, &t.tm_mday, &t.tm_hour, &t.tm_min);
    t.tm_year -= 1900;
    t.tm_mon -= 1;
    t.tm_sec = 0;
    return mktime(&t);
}

int main() {
    cout << "Content-Type: text/html\n\n";

    string qs = getenv("QUERY_STRING") ? getenv("QUERY_STRING") : "";

    string owner      = getParam(qs, "owner");
    string vehicle    = getParam(qs, "vehicle");
    string vehicletype= getParam(qs, "vehicletype");
    string phone      = getParam(qs, "phone");
    string slot       = getParam(qs, "slot");
    string purpose    = getParam(qs, "purpose");
    string entry      = getParam(qs, "entry");
    string exitT      = getParam(qs, "exit");
    string notes      = getParam(qs, "notes");

    time_t tEntry = parseDateTime(entry);
    time_t tExit  = parseDateTime(exitT);

    double seconds = difftime(tExit, tEntry);
    double hours = seconds / 3600.0;
    if (hours < 0) hours = 0;

    // Fee rules (adjustable)
    double ratePerHour = 20.0; // ₹20 per hour
    double amount = ratePerHour * hours;
    if (hours < 1 && hours > 0) amount = ratePerHour; // minimum 1 hour fee

    // Save as CSV (escape commas by replacing with semicolon)
    auto esc = [](string s){
        for (char &c : s) if (c == ',') c = ';';
        return s;
    };

    ofstream out("parking_log.csv", ios::app);
    out << esc(owner) << "," << esc(vehicle) << "," << esc(vehicletype) << "," << esc(phone) << ","
        << esc(slot) << "," << esc(purpose) << "," << entry << "," << exitT << ","
        << fixed << setprecision(2) << hours << "," << fixed << setprecision(2) << amount << "," << esc(notes)
        << "\n";
    out.close();

    // Show receipt
    cout << "<html><head><meta charset='utf-8'><title>Receipt</title></head><body style='background:#0d0d0d;color:#eee;font-family:Arial;padding:18px'>";
    cout << "<div style='max-width:720px;margin:auto;background:#121215;padding:18px;border-radius:10px'>";
    cout << "<h2 style='color:#fff'>Parking Receipt</h2>";
    cout << "<p><b>Owner:</b> " << owner << "</p>";
    cout << "<p><b>Vehicle:</b> " << vehicle << " (" << vehicletype << ")</p>";
    cout << "<p><b>Slot:</b> " << slot << " &nbsp; <b>Phone:</b> " << phone << "</p>";
    cout << "<p><b>Purpose:</b> " << purpose << "</p>";
    cout << "<p><b>Entry:</b> " << entry << "</p>";
    cout << "<p><b>Exit:</b> " << exitT << "</p>";
    cout << "<p><b>Hours:</b> " << fixed << setprecision(2) << hours << " &nbsp; <b>Fee:</b> Rs. " << fixed << setprecision(2) << amount << "</p>";
    cout << "<p><b>Notes:</b> " << notes << "</p>";
    cout << "<hr style='border:none;border-top:1px solid rgba(255,255,255,0.06)'>";
    cout << "<p><a href='dashboard.cgi' style='color:#9adf73'>Open Dashboard</a> &nbsp; ";
    cout << "<a href='parking_log.csv' style='color:#9adf73' download>Download CSV</a> &nbsp; ";
    cout << "<a href='index.html' style='color:#9adf73'>Home</a></p>";
    cout << "</div></body></html>";

    return 0;
}
